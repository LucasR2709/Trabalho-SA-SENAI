function abrirpopup() {
    var detalhes = document.getElementById('detalhes');

    if (detalhes.style.display == 'block') {
        detalhes.style.display = 'none'
    } else {
        detalhes.style.display = 'block'
    }

    console.log('filho da puta')
}